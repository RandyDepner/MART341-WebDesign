You type a website's URL into your browsers address. Then your browser locates and requests the pages information from a web server. The browser receives a file in a computer code like HTML or Javascript, this will include instructions about how to display the information on that page. http://old.mangago.com/terms.php

Markup language is a system for annotating a document in a way that is syntactically distinguishable from the text, meaning when the document is processed for display, the markup language is not shown and is only used to format the text. Ex. Marking up a paper or manuscript?

![Screenshot](./images/Assighment-04images:.png)
