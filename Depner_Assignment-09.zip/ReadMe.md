1.) Learning HTML was all very new to me and I thought it was a very interesting element to learn and use.

2.) Everything is new to me so I an anxious and excited to learn new ways to decorate HTML's in anyway.

3.) I really enjoyed going back and looking at how slime was made and played with during this excerise. I thought the multiple pages were tie consuming but in the end the end product was amazing as always to look at.
