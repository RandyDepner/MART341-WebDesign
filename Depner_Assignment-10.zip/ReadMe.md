
1.) So a type selector is referred to as a tag name selector or element selector because it selects an HTML tag/element in your document.
Secondly, The universal selector is indicated by an asterisk *. It selects everything in the document (or inside the parent element if it is being chained together with another element and a descendant combinator). Thirdly, The class selector starts with a dot '.' in it. It will select everything in the document with that class applied to it. Finally, one can apply multiple classes to an element and target them individually, or only select the element (when all of the classes in the selector are present). This can be very helpful when building up components that can be combined in different ways when you build your own site.
I would choose one over the other when it comes to styling the content of my site so if I want to change one thing and not everything on my site that would be nice.

2.) I chose a color palette that was similar to the color of many poodle skirts from back in the day.

background-color: rgb(232,232,232)
background-color: lightblue
color: rgb(0, 0, 0,)
background-color: #81B3DE
background-color: rgb(232, 160, 232, 0.7)
background-color:grey
background-color: darkgray

3.) at first I didnt know how to get the colors for the css style code page, but then I just looked up 'code color numbers and that fixed my biggest problem'.
