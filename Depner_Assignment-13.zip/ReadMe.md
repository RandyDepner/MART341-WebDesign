1.) My imaginary client is me. I wanted my sight needs to come off cool and yet fun to the viewers eyes. I wanted it to display some of my fun creations so they maybe someone might want to contact me for a commission.

2.)Mobile first design is a design strategy that says when you create a website or app, you should start sketching and prototyping the smallest screen first and work your way up to larger screens. Essentially, it’s about delivering the right user experience to the right device.

3.) I had problems with images showing up again but I quickly fixed that. I also had over thought who my client should be so I just choose myself.
