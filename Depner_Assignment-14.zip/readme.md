1.) I choose a bootstrap because I was also lost with a friend of mine on how to get this to work.....

2.) CDN to make everything easier to access and everything less chaotic.

3.)HTML5 allows you to select elements by tag name, or by the same mechanisms you use to select elements in CSS. Local storage mechanisms: Previous versions of HTML allowed very limited storage of information on the client. HTML5 now allows the developer to store data on the client.

4.)This week was hard due to all the pages and other related works. I beleive getting all links, images and information into all asked insturctions was difficult but also the canvas element was hard to use and make work so I am still unsure if it works and how to make it work.....
