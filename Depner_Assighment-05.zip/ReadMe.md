1. I went back to cartoonnetwork.com because I use to go on this website and play the games provided their to relieve stress from school and daily life as a kid. The format has changed a lot since I last saw it. I liked the orignial class of the 10 year look better than the now verison.

![screenshot](Cartoonnetwork.JPG)

2. Everything was very difficult for me because I have never taken coding and I need this upper division class no matter what to gradutate so I am trying my hardest with the support and examples that friends show me to help me learn each weeks lesson. I may lack in areas but I shine in others. I find everything very hard to understand without a visual guide, for example the Youtube video that showed us how to enmbed an image was VERY helpful and my friend showing me how they do there Githubs help a lot with my lack of knowledge in coding. :)

![screenshot](Anwser.JPG)
