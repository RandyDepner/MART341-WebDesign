1.) I have come across subscriptions, email/number sign ups, and even newsletters. Newsletters serve as small tiny advervisments. Subscriptions/ email/ phone numbers are all basically the same, you get a notification about when a new product is out or if there is a hot sale on an item.

2.) A Text defines a one-line text input field.  A Checkbox selection defines checkbox's which allows select one option. And lastly, A button input Defines a simple push button, which can be programmed to perform a task on an event.

3.) My work cycle for this assignment was just placing the code and double checking my final product to see if everything came out correctly.
