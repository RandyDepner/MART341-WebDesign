1.)Padding is the space inside the border of a block that separates the border from the content. The margin is the spacing outside the border that separates a block from the adjacent blocks. Another difference is that padding includes the background image and background colors applied around the content while margin does not contain them. The margins of adjacent blocks may sometimes overlap when the browser render the page but for padding such thing will not happen.
Border is the strip that goes around your div/element of the content. Padding is the space between the content and the border. Margin is the space outside the border. padding is the space between the content and the border, whereas margin is the space outside the border.


2.) Some challenges that I had was no instruction sheet and I over came this by asking a friend what they did so I didn't overthink this assignment completely.
