1.) I learned so much about Web development because I have never done it before and this is my first class ever on it. I believe at most times it was frustrating and hard to understand but the help for external sources and a friend really helped and expended that overwhelming fear within this class. I enjoyed it a lot and hope many more students do as well.

2.) Like I mentioned in the answer above, I'm completely new to this so everything was new and I learned so much about web design this semester! :)

3.) I had many challenges, as I was new to coding and web design, but I over came them by working hard and asking questions when I was absoultely stuck! :)
