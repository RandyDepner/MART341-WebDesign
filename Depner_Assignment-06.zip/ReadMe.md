13.) I guess there can be only one <body> element in an HTML document because this element is the container that holds the content of the document and all of the content one can see is rendered in the browser is contained within this element. ... but also, apparently Having multiple html, body and head tags does not affect the performance of the page parsing. But be aware that the browser will probably run in a quirks mode and affect the rendering of any of your elements.

14.) Structural markup is the element that you can use to describe both headings and paragraphs when sematic markup is when it provides extra information; such as where emphasis is placed in a sentence, that something you have written is a quotation (and who said it), the meaning of acronyms.

15.) Summarize my work cycle for this assignment?...um I had to:
- open atom
- make a file
- name my files in my folder
- find a Recepie
- look up and anwser questions in my Readme.md
(i also checked on my index.html file and opened it in windows and saw that it wasn't empty this time and I do not know what happened last time to my other index files to make it do that.)
