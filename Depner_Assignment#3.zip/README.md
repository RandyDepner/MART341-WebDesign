#Assignment 3
##Randy Depner

[favorite website] (https://www.amazon.com/gp/video/storefront/ref=sv_atv_logo?node=2858778011)
[My Responses](./response.txt)
![screenshot](.images/Assignment-03images:.png)
https://umt.app.box.com/notes/769609420091
