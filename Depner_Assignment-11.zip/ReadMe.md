1.) Web-safe fonts include serif, sans, and symbol typefaces. While some of them were originally designed for print, others have been designed specifically for legibility on the screen.
Safe WebFonts that just with CSS are rendered correctly. No any TrueType, WOFF, SVG or EOT file is required.

2.)It is Better to have your font fall back to something close to your top choice than to something totally unrelated! There is a fantastic tool by Monica Dinculescu call Font style matcher where you can play with fallbacks.

3.) font challenging but I think I got it?
