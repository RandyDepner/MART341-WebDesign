1.) a Div Tag is a block level HTML element. It is used to divide or section of other HTML tags in to meaningful groups.
A Span Tag is an inline HTML element that is used to group a set of inline elements. For example, when you use span to hook text or a group of tags you want to style differently.
Id Attribute is used to label sections or parts of your HTML document. You may only use the same id once per age, save it for important sections of page.
Class Attribute is if a page had multiple sidebar chunks, you might want to make one class so that you could use CSS to style each chunk with one rule.

2.) I beleive I had read that hosting a video on YouTube and Vimeo is difficult because you may not know if the video is pritive or not to share with others, so they may be able to access that video without signing in to an account or not.
YouTube and Vimeo have a great video sharing system...
( To be honest I have never used Vimeo so I do not know fully how it works and how I could defend it in a statement. XD )

3.) I had a problem again with the image showing up, with the Soundcloud and the YouTube link. I overcame them by asking for help from a fellow classmate who also didn't know what was wrong but I finally figure out my code problems and continued to make them all work and show up for this weeks assignment.
